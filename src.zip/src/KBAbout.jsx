import React from 'react'

export const KBAbout = () => {
  return (
    <div>
        <div id='adiv1'>
          <h1 id='ah1'>KNIGHT BITE IS A CLOUD KITCHEN WHICH DELIVERS FOOD TO THE NOCTURNALS GIVING EQUAL EMPHASIS ON FOOD, TECHNOLOGY AND LOGISTICS.</h1>
        </div>
        <div id='adiv2'>
          <img src="https://knight-bite.com/res/about/food-strip.webp" alt=""  />
          <p>Knight Bite started with the idea to serve all the hungry nocturnals who find it really difficult to order late night muchies. KB brought together late night eaters and helped them order delicious meals at their convenience via Knight Bite App and call.</p>
          <p id='adiv2p1'>Knight Bite is one such concept which was highly successful in adapting to the emerging market.

<br /><br /><br />Biters (customers), accepted and loved the KB app that made the ordering process much more easier. In two weeks of the release of the app, it was trending on top food apps and was downloaded by more than 5000 users across Mangalore and Manipal.</p>
          <img  className='adiv2i1' src="https://knight-bite.com/res/about/app-menu.webp" alt="" />
          <img className='adiv2i2' src="https://knight-bite.com/res/about/burger.webp" alt="" />
          <p id='adiv2p1'>Going forward, our aim is to help and bring smiles in many more faces and cover many more cities across India and around the world.</p>
        </div>
        <div id='adiv3'>
          <div >
            <h1 id='adiv3h1'>Locations</h1><br/>
            <ul itemType='circle' id='adiv3ul'>
              <li><b >Bengaluru</b> Hours: 7:00 pm - 4:00 am</li>
              <li><b>Mangalore</b> Hours: 7:00 pm - 4:00 am</li>
              <li><b>Mysuru</b> Hours: 7:00 pm - 4:00 am</li>
              <li><b>Hyderabad</b> Hours: 7:00 pm - 4:00 am</li>
              <li><b>Hubli</b> Hours: 7:00 pm - 4:00 am</li>
              <li><b>Manipal</b> Hours: 7:00 pm - 4:00 am</li>
            </ul>
          </div>
          <div>
            <h1 id='div31h'>Follow Us</h1><br />
           <img src="https://knight-bite.com/res/instagram.svg" alt="" className='hi'/>
           <img src="https://knight-bite.com/res/facebook.svg" alt="" className='hi'/>
           <img src="https://knight-bite.com/res/linkedin.svg" alt="" className='hi'/>
           <img src="https://knight-bite.com/res/youtube.svg" alt="" className='hi' />
          </div>
        </div><br />
        <div id='footer'>&copy; Copyright 2024. Knight Bite Pvt. Ltd. All Rights Reserved</div>
       
    </div>
  )
}
