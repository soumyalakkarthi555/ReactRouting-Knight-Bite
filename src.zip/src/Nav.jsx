import React from 'react';
// import MailOutlineIcon from '@mui/icons-material/MailOutline';
// import PhoneIcon from '@mui/icons-material/Phone';
// import './Nav.css'; // CSS file for styling

const Nav = () => {

  return (
    <>
    <div  className="nav-bar-img">
    <nav className="nav-bar">
      <div><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSwIDt_OeRPXBZ1uGdfEn70sBPfsqZ3H3sv8Zo3X4BkNg&s" alt="" className='logo-img'/><p className='knightbite'>KNIGHT BITE</p></div>
      <ul className="nav-menu">
        <li><a href="#" >Home</a></li>
        <li><a href="#">About</a></li>
        <li><a href="#">Services</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
    </nav>
    </div>
    </>


  );
};

export default Nav;
