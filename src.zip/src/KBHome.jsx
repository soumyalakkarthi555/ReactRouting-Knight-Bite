import React from 'react'
// import MailOutlineIcon from '@mui/icons-material/MailOutline';
// import PhoneIcon from '@mui/icons-material/Phone';

export const KBHome = () => {
  return (
    <div className='mainhdiv' >
      <div className='hdiv1'>
           <h1 id='hdiv1h1' style={{color:'white',paddingTop:'200px',fontSize:'50px',paddingLeft:'80px'}}>DELICIOUSNESS, ONE CLICK AWAY!</h1>
           <button id='hb1' style={{backgroundColor:'#FF5672',borderRadius:"5px",padding:'5px',marginLeft:'60px'}}>Order On Web</button> <br /> <p style={{color:'white',paddingLeft:'60px',fontSize:'larger'}}>or</p><br />
           <img src="https://knight-bite.com/res/index/ios-store.svg" alt="" id='hi1' className='img1'/> ----
           <img src="https://knight-bite.com/res/index/google-play-badge.svg" alt="" id='hi2' className='img12'/>
      </div>
    <div><h1 style={{paddingTop:'100px',paddingLeft:'600px'}}>Features</h1> <br /><br />
    <div class="hdiv2">
    <img src="https://knight-bite.com/res/index/feature-1.svg" alt="" />
    <img src="https://knight-bite.com/res/index/feature-2.svg" alt="" />
    <img src="https://knight-bite.com/res/index/feature-3.svg" alt="" />
    <img src="https://knight-bite.com/res/index/feature-4.svg" alt="" />
    <img src="https://knight-bite.com/res/index/feature-5.svg" alt="" />
    </div>
    <div class="hdiv2">
        <p class="hp1">Late Night Delivery by <br />
Till 4 Am</p>
        <p class="hp1">Order On App Or <br />Call 080-4710607</p>
        <p class="hp1">Delivery Within 40 <br /> Mins</p>
        <p class="hp1">Food For Every Kind <br />Of Hunger</p>
        <p class="hp1">Place Bulk Orders <br />Through App</p>
    </div>
    <div className='hdiv3'>
      
      <h1 className='hdh3'>ENJOY FOOD, ENJOY LIFE</h1>
    </div>
    <div className='hdiv4'>
   <h1 className='hdvi4h1'>BURGER, FRIES, SHAKES </h1>
   <h1 className='hdvi4h2'>AND MANY MORE</h1>
   <button id='hdiv4b'>See Full Menu</button>
    </div>
    </div>
     <div>
      <h1 style={{paddingTop:'50px'}}>Connect with us</h1><br /><br />
      <div className='flexdiv'>
        <div>
          <h3>Contact us</h3>
          <div> 
          {/* <MailOutlineIcon style={{color:' #FF5672'}}></MailOutlineIcon>
            <p>info@knight-bite.com</p>
            <PhoneIcon style={{color:' #FF5672'}}></PhoneIcon> */}
             <h6>+91 8047106107</h6>
             <p>available from 7pm to 4am</p>
          </div>
        </div>
        <div>
        
          <ul ><b>Quick Links</b><br /><br />
            <li style={{color:' #FF5672'}}>Delivery Policies</li><br />
            <li style={{color:' #FF5672'}}>Privacy Policies</li><br />
            <li>Careers(Coiming soon)</li><br />
            <li style={{color:' #FF5672'}}>Franchise</li>
          </ul>
        </div>
        <div>
          <p>Enter your email address below to be the first to know everything about us, where we’ll <br /><br /> be next, and how you can come along! <br /><br />
Join us on our adventure.
</p>
<input type="text" placeholder='Enter your Email address'></input> 
        </div>
      </div> <br /><br />
<div className='flexdiv'>
<div>
  <h4>Head Office</h4>
  <p>1st Floor, No 20-1-7/10, Regal Square <br /> Azizuddin Road, Bunder Mangalore,<br /> Bunder, Mangaluru, Dakshina Kannada,<br /> Karnataka, 575001</p>
</div>
<div>
  <h4>Location</h4>
  <p>Bengaluru, Mangalore, Mysuru,<br /> Hyderabad, Hubli, Manipal, Udupi</p>
</div>
<div>
<h4 id='div31h'>Follow Us</h4><br />
           <img src="https://knight-bite.com/res/instagram.svg" alt="" className='hi'/>
           <img src="https://knight-bite.com/res/facebook.svg" alt="" className='hi'/>
           <img src="https://knight-bite.com/res/linkedin.svg" alt="" className='hi'/>
           <img src="https://knight-bite.com/res/youtube.svg" alt="" className='hi' />
</div>
</div>
     </div>
    <div id='footer'>&copy; Copyright 2024. Knight Bite Pvt. Ltd. All Rights Reserved</div>
            </div>
  )
}
